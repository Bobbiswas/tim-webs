console.log("[DEVTOOL]","Self-maintaining global modules initialized!!!"),window.vendorList=[];
//# sourceMappingURL=devtool.app.6fb73acd.js.map
